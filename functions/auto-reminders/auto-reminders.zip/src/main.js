import { Client, Databases, Query, ID } from 'node-appwrite';

// ============================================================
// 🎯 TEMPLATES
// ============================================================
const quoteTemplates = {
  1: `Bonjour {clientName},\n\nJe me permets de revenir vers vous concernant le devis n°{number} que je vous ai transmis le {date} pour un montant de {amount}.\n\nAvez-vous pu en prendre connaissance ? Je reste à votre entière disposition pour répondre à vos questions ou ajuster l'offre selon vos besoins.\n\nVous pouvez consulter et accepter le devis en ligne via ce lien :\n{link}\n\nCordialement,\n{companyName}`,
  2: `Bonjour {clientName},\n\nJe fais suite à mon précédent message concernant le devis n°{number} d'un montant de {amount}, transmis le {date}.\n\nJe n'ai pas reçu de retour de votre part et je souhaitais m'assurer que vous aviez bien reçu notre proposition.\n\nVous pouvez consulter et accepter le devis en ligne via ce lien :\n{link}\n\nCordialement,\n{companyName}`,
  3: `Bonjour {clientName},\n\nJe me permets de vous recontacter une dernière fois concernant le devis n°{number} d'un montant de {amount}.\n\nNotre offre arrive à expiration prochainement. Sans retour de votre part sous 7 jours, nous considérerons cette offre comme caduque.\n\nVous pouvez consulter et accepter le devis en ligne via ce lien :\n{link}\n\nCordialement,\n{companyName}`,
};

const invoiceTemplates = {
  1: `Bonjour {clientName},\n\nSauf erreur ou omission de notre part, la facture n°{number} d'un montant de {amount}, arrivée à échéance le {date}, n'a pas encore été réglée.\n\nNous vous remercions de bien vouloir procéder au règlement dans les meilleurs délais.\n\nVous pouvez consulter et régler la facture en ligne via ce lien :\n{link}\n\nCordialement,\n{companyName}`,
  2: `Bonjour {clientName},\n\nMalgré notre précédente relance, nous constatons que la facture n°{number} d'un montant de {amount}, échue le {date}, n'a toujours pas été réglée.\n\nNous vous prions de bien vouloir procéder au règlement sous 8 jours.\n\nVous pouvez consulter et régler la facture en ligne via ce lien :\n{link}\n\nCordialement,\n{companyName}`,
  3: `MISE EN DEMEURE DE PAYER\n\n{clientName},\n\nMalgré nos multiples relances, la facture n°{number} d'un montant de {amount}, échue le {date}, demeure impayée à ce jour.\n\nPar la présente, nous vous mettons en demeure de procéder au règlement intégral de cette somme sous 8 jours.\n\nVous pouvez consulter et régler la facture en ligne via ce lien :\n{link}\n\n{companyName}`,
};

// ============================================================
// 🛠️ HELPERS
// ============================================================
const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;
const formatCurrency = (amount, symbol = '€') => `${round2(amount).toFixed(2)} ${symbol}`;

const buildMessage = (type, level, vars) => {
  const templates = type === 'quote' ? quoteTemplates : invoiceTemplates;
  const template = templates[level] || templates[1];
  return template
    .replace(/{clientName}/g, vars.clientName)
    .replace(/{number}/g, vars.number)
    .replace(/{amount}/g, vars.amount)
    .replace(/{date}/g, vars.date)
    .replace(/{link}/g, vars.link)
    .replace(/{companyName}/g, vars.companyName);
};

const isWeekend = () => {
  const day = new Date().getDay();
  return day === 0 || day === 6;
};

// ============================================================
// 📧 ENVOI EMAILJS (API REST)
// ============================================================
async function sendEmail(to, subject, message, companyName) {
  const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      service_id: process.env.EMAILJS_SERVICE_ID,
      template_id: process.env.EMAILJS_TEMPLATE_ID,
      user_id: process.env.EMAILJS_PUBLIC_KEY,
      accessToken: process.env.EMAILJS_PUBLIC_KEY,
      template_params: {
        to_email: to,
        to_name: to.split('@')[0],
        subject: subject,
        message: message,
        company_name: companyName || 'RelancePro',
      },
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`EmailJS ${response.status}: ${text}`);
  }
  return true;
}

// ============================================================
// 💾 TRAÇABILITÉ
// ============================================================
async function recordFollowup(databases, databaseId, teamId, type, targetId, number, clientName, level, message, email) {
  const now = new Date().toISOString();
  await databases.createDocument(databaseId, 'followups', ID.unique(), {
    scheduledAt: now,
    teamId,
    userId: 'system-cron',
    targetType: type,
    targetId,
    relatedNumber: number,
    clientName,
    level: String(level),
    followupType: 'relance_auto',
    channel: 'email',
    sentAt: now,
    status: 'sent',
    message,
    recipientEmail: email || '',
  });
}

// ============================================================
// 🚀 MAIN
// ============================================================
export default async function ({ req, res, log, error }) {
  log('🚀 Démarrage du cron auto-reminders (EmailJS)');

  if (isWeekend()) {
    log('📅 Week-end détecté — aucune relance envoyée.');
    return res.json({ skipped: true, reason: 'weekend' });
  }

  const client = new Client()
    .setEndpoint(process.env.APPWRITE_ENDPOINT || 'https://cloud.appwrite.io/v1')
    .setProject(process.env.APPWRITE_PROJECT_ID)
    .setKey(process.env.APPWRITE_API_KEY);

  const databases = new Databases(client);
  const DATABASE_ID = process.env.DATABASE_ID || 'relancepro_db';
  const BASE_URL = process.env.BASE_URL || 'https://votre-domaine.com';

  if (!process.env.EMAILJS_SERVICE_ID || !process.env.EMAILJS_TEMPLATE_ID || !process.env.EMAILJS_PUBLIC_KEY) {
    error('❌ Variables EmailJS manquantes');
    return res.json({ error: 'EmailJS non configuré' });
  }

  const teamsRes = await databases.listDocuments(DATABASE_ID, 'teams', [Query.limit(100)]);
  let totalSent = 0;
  let totalFailed = 0;
  const report = [];

  for (const team of teamsRes.documents) {
    const teamId = team.$id;
    log(`\n=== Équipe ${teamId} ===`);

    let quotes = [], invoices = [], followups = [];
    try {
      const [qRes, iRes, fRes] = await Promise.all([
        databases.listDocuments(DATABASE_ID, 'quotes', [Query.equal('teamId', teamId), Query.limit(500)]),
        databases.listDocuments(DATABASE_ID, 'invoices', [Query.equal('teamId', teamId), Query.limit(500)]),
        databases.listDocuments(DATABASE_ID, 'followups', [
          Query.equal('teamId', teamId),
          Query.greaterThanOrEqual('sentAt', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()),
          Query.limit(500),
        ]),
      ]);
      quotes = qRes.documents;
      invoices = iRes.documents;
      followups = fRes.documents;
    } catch (e) {
      error(`Erreur chargement équipe ${teamId}:`, e);
      continue;
    }

    let companyName = 'Votre entreprise';
    try {
      const sRes = await databases.listDocuments(DATABASE_ID, 'company_settings', [
        Query.equal('userId', team.ownerId || ''), Query.limit(1),
      ]);
      if (sRes.documents.length > 0) companyName = sRes.documents[0].name || companyName;
    } catch { /* ignore */ }

    const sentRecently = new Set(followups.map(f => `${f.targetType}:${f.targetId}`));
    const today = new Date();

    // ---------- DEVIS ----------
    for (const quote of quotes) {
      if (quote.status !== 'Envoyé' || !quote.clientEmail) continue;
      const issueDate = new Date(quote.issueDate || '');
      const daysSinceSent = Math.floor((today - issueDate) / (1000 * 60 * 60 * 24));
      const validityDate = quote.validityDate ? new Date(quote.validityDate) : null;
      const daysUntilExpiry = validityDate ? Math.floor((validityDate - today) / (1000 * 60 * 60 * 24)) : null;

      let level = null;
      if (daysUntilExpiry !== null && daysUntilExpiry < 0) level = 3;
      else if (daysUntilExpiry !== null && daysUntilExpiry <= 3) level = 2;
      else if (daysSinceSent >= 15) level = 3;
      else if (daysSinceSent >= 7) level = 2;
      else if (daysSinceSent >= 3) level = 1;
      if (!level) continue;

      const key = `quote:${quote.$id}`;
      if (sentRecently.has(key)) continue;

      const message = buildMessage('quote', level, {
        clientName: quote.clientName,
        number: quote.quoteNumber,
        amount: formatCurrency(quote.total || 0),
        date: issueDate.toLocaleDateString('fr-FR'),
        link: quote.clientToken ? `${BASE_URL}/v/${quote.clientToken}` : '[Lien non disponible]',
        companyName,
      });

      try {
        await sendEmail(quote.clientEmail, `Relance - Devis n°${quote.quoteNumber}`, message, companyName);
        await recordFollowup(databases, DATABASE_ID, teamId, 'quote', quote.$id, quote.quoteNumber, quote.clientName, level, message, quote.clientEmail);
        sentRecently.add(key);
        totalSent++;
        report.push({ type: 'quote', number: quote.quoteNumber, level });
        log(`✅ Devis ${quote.quoteNumber} relancé (niveau ${level})`);
      } catch (e) {
        error(`❌ Échec devis ${quote.quoteNumber}:`, e);
        totalFailed++;
      }
    }

    // ---------- FACTURES ----------
    for (const invoice of invoices) {
      if (['paid', 'cancelled'].includes(invoice.status)) continue;
      if (invoice.type === 'credit' || !invoice.clientEmail) continue;
      const balance = invoice.balance ?? invoice.total ?? 0;
      if (balance <= 0) continue;

      let level = null;
      let subjectPrefix = 'Facture';

      if (invoice.isElectronic && invoice.transmissionStatus === 'transmitted') {
        const transmittedDate = new Date(invoice.$updatedAt || invoice.issueDate || '');
        const days = Math.floor((today - transmittedDate) / (1000 * 60 * 60 * 24));
        if (days >= 7) level = 2;
        else if (days >= 3) level = 1;
        if (level) subjectPrefix = 'E-Facture';
      }

      if (!level && invoice.dueDate) {
        const daysOverdue = Math.floor((today - new Date(invoice.dueDate)) / (1000 * 60 * 60 * 24));
        if (daysOverdue >= 30) level = 3;
        else if (daysOverdue >= 15) level = 2;
        else if (daysOverdue > 0) level = 1;
      }
      if (!level) continue;

      const key = `invoice:${invoice.$id}`;
      if (sentRecently.has(key)) continue;

      const message = buildMessage('invoice', level, {
        clientName: invoice.clientName,
        number: invoice.invoiceNumber,
        amount: formatCurrency(balance),
        date: new Date(invoice.dueDate || invoice.issueDate || '').toLocaleDateString('fr-FR'),
        link: invoice.clientToken ? `${BASE_URL}/f/${invoice.clientToken}` : '[Lien non disponible]',
        companyName,
      });

      try {
        await sendEmail(invoice.clientEmail, `Relance - ${subjectPrefix} n°${invoice.invoiceNumber}`, message, companyName);
        await recordFollowup(databases, DATABASE_ID, teamId, 'invoice', invoice.$id, invoice.invoiceNumber, invoice.clientName, level, message, invoice.clientEmail);
        sentRecently.add(key);
        totalSent++;
        report.push({ type: subjectPrefix.toLowerCase(), number: invoice.invoiceNumber, level });
        log(`✅ ${subjectPrefix} ${invoice.invoiceNumber} relancée (niveau ${level})`);
      } catch (e) {
        error(`❌ Échec ${subjectPrefix} ${invoice.invoiceNumber}:`, e);
        totalFailed++;
      }
    }
  }

  log(`\n🎯 BILAN : ${totalSent} envoyée(s), ${totalFailed} échec(s)`);
  return res.json({ success: true, sent: totalSent, failed: totalFailed, details: report, executedAt: new Date().toISOString() });
}